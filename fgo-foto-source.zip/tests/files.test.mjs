import test from 'node:test';
import assert from 'node:assert/strict';
import { fileKey, uniqueJpegName, readEntry, saveInDirectory } from '../web/files.js';

test('JPEG names keep Turkish names, flatten paths and avoid collisions', () => {
  const used = new Set();
  assert.equal(uniqueJpegName('hasta/diş.CR3', used), 'diş.jpg');
  assert.equal(uniqueJpegName('diş.cr3', used), 'diş_1.jpg');
  assert.equal(uniqueJpegName('x\\image.CR3', used), 'image.jpg');
  assert.equal(uniqueJpegName('IMAGE.CR3', used), 'IMAGE_1.jpg');
  assert.equal(uniqueJpegName('../photo?.cr3', used), 'photo_.jpg');
});

test('file keys distinguish same name from different folders', () => {
  assert.notEqual(fileKey({ name: '1.cr3', webkitRelativePath: 'a/1.cr3', size: 10, lastModified: 1 }), fileKey({ name: '1.cr3', webkitRelativePath: 'b/1.cr3', size: 10, lastModified: 1 }));
});

test('dropped directories are read across multiple batches', async () => {
  const file = { name: 'foto.cr3' };
  const entry = { isFile: true, file: (resolve) => resolve(file) };
  let count = 0;
  const folder = { isDirectory: true, createReader: () => ({ readEntries: (resolve) => resolve(count++ < 2 ? [entry] : []) }) };
  const result = [];
  for await (const found of readEntry(folder)) result.push(found);
  assert.equal(result.length, 2);
});

test('directory output preserves existing JPEG and closes new file', async () => {
  const calls = [];
  const directory = { async getFileHandle(name, options) {
    if (!options && name === 'foto.jpg') return {};
    if (!options) throw new DOMException('Missing', 'NotFoundError');
    calls.push(name);
    return { async createWritable() { return { async write(data) { calls.push(data); }, async close() { calls.push('closed'); } }; } };
  } };
  assert.equal(await saveInDirectory(directory, 'foto.jpg', 'bytes'), 'foto_1.jpg');
  assert.deepEqual(calls, ['foto_1.jpg', 'bytes', 'closed']);
});

test('directory permission error does not overwrite or create files', async () => {
  const directory = { async getFileHandle() { throw new DOMException('Denied', 'NotAllowedError'); } };
  await assert.rejects(saveInDirectory(directory, 'foto.jpg', 'bytes'), { name: 'NotAllowedError' });
});
