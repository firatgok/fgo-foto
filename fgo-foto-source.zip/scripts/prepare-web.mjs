import { cp, mkdir, writeFile } from 'node:fs/promises';
const root = new URL('../', import.meta.url);
const publicDir = new URL('web/public/', root);
await mkdir(new URL('vendor/libraw/', publicDir), { recursive: true });
await mkdir(new URL('licenses/', publicDir), { recursive: true });
await cp(new URL('node_modules/libraw-wasm/dist/', root), new URL('vendor/libraw/', publicDir), { recursive: true });
await cp(new URL('node_modules/coi-serviceworker/coi-serviceworker.js', root), new URL('coi-serviceworker.js', publicDir));
await cp(new URL('node_modules/coi-serviceworker/LICENSE', root), new URL('vendor/COI-LICENSE.txt', publicDir));
// Keep npm attribution beside the checked-in native-library notices. The
// libraw-wasm tarball declares ISC in package.json but ships no LICENSE file.
// Source versions and native licenses are documented in third-party.html.
await Promise.all([
  ['libraw-wasm/package.json', 'libraw-wasm-package.json'],
  ['libraw-wasm/readme.md', 'libraw-wasm-README.md'],
  ['coi-serviceworker/LICENSE', 'coi-serviceworker-MIT.txt'],
  ['coi-serviceworker/package.json', 'coi-serviceworker-package.json'],
  ['fflate/LICENSE', 'fflate-MIT.txt'],
  ['fflate/package.json', 'fflate-package.json'],
].map(([source, destination]) => cp(
  new URL(`node_modules/${source}`, root),
  new URL(`licenses/${destination}`, publicDir),
)));
await writeFile(new URL('.nojekyll', publicDir), '');
console.log('Tarayıcı dönüşüm motoru ve GitHub Pages dosyaları hazır.');
