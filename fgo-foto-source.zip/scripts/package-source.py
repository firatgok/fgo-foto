"""Create a reviewable GitHub source bundle; never include photos or local state."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
top = ['package.json', 'package-lock.json', 'vite.config.js', 'README.md', '.gitignore']
files = [root / name for name in top]
for folder in ('scripts', 'tests', 'web'):
    for path in (root / folder).rglob('*'):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative.startswith('web/public/vendor/') or relative in ('web/public/coi-serviceworker.js', 'web/public/.nojekyll'):
            continue
        files.append(path)
with ZipFile(root / 'fgo-foto-source.zip', 'w', ZIP_DEFLATED) as archive:
    for path in sorted(files):
        archive.write(path, path.relative_to(root).as_posix())
print(f'Prepared {len(files)} source files ({(root / "fgo-foto-source.zip").stat().st_size:,} bytes).')
