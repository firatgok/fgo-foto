import { defineConfig } from 'vite';

export default defineConfig({
  root: 'web',
  base: './',
  build: { outDir: '../dist', emptyOutDir: true },
  worker: { format: 'es' },
  // Production uses the same-origin COI service worker on GitHub Pages.
  server: { host: '127.0.0.1' },
  preview: { host: '127.0.0.1' },
});
