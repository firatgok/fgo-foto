let libRawModulePromise;
let queue = Promise.resolve();

async function processRaw({ buffer, quality, moduleUrl }) {
  // The whole upstream dist folder is vendored verbatim. Its nested worker,
  // pthread worker and .wasm URLs must stay beside its index.js.
  libRawModulePromise ??= import(/* @vite-ignore */ moduleUrl).catch((error) => {
    libRawModulePromise = null;
    throw error;
  });
  const { default: LibRaw } = await libRawModulePromise;
  const raw = new LibRaw();
  const workerFailure = new Promise((_, reject) => {
    raw.worker.addEventListener('error', () => reject(new Error('RAW motoru başlatılamadı veya kullanılabilir bellek yetersiz.')));
    raw.worker.addEventListener('messageerror', () => reject(new Error('RAW motorundan görüntü alınamadı.')));
  });
  try {
    const image = await Promise.race([
      (async () => {
        await raw.open(new Uint8Array(buffer), {
          useCameraWb: true,
          useAutoWb: false,
          useCameraMatrix: 1,
          outputColor: 1,
          outputBps: 8,
          halfSize: false,
          fourColorRgb: false,
          userQual: 3,
          userFlip: -1,
          noAutoBright: false,
        });
        return raw.imageData();
      })(),
      workerFailure,
    ]);
    const { width, height, colors, bits, data } = image || {};
    if (!Number.isInteger(width) || !Number.isInteger(height) || width <= 0 || height <= 0
      || bits !== 8 || ![1, 3, 4].includes(colors) || !data || data.length !== width * height * colors) {
      throw new Error('RAW dosyasından geçerli bir görüntü elde edilemedi.');
    }
    // imageData() returns owned pixel bytes; release the decoder before the
    // additional RGBA/canvas allocations to keep the peak memory lower.
    raw.dispose();
    const rgba = new Uint8ClampedArray(width * height * 4);
    for (let source = 0, target = 0; source < data.length; source += colors, target += 4) {
      rgba[target] = data[source];
      rgba[target + 1] = data[source + (colors === 1 ? 0 : 1)];
      rgba[target + 2] = data[source + (colors === 1 ? 0 : 2)];
      rgba[target + 3] = 255;
    }
    if (typeof OffscreenCanvas !== 'undefined') {
      const canvas = new OffscreenCanvas(width, height);
      try {
        const context = canvas.getContext('2d', { alpha: false, colorSpace: 'srgb' });
        if (context && typeof canvas.convertToBlob === 'function') {
          context.putImageData(new ImageData(rgba, width, height), 0, 0);
          const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: quality / 100 });
          if (blob.type === 'image/jpeg' && blob.size > 0) return { blob, width, height };
        }
      } finally {
        canvas.width = 0;
        canvas.height = 0;
      }
    }
    return { rgba: rgba.buffer, width, height };
  } finally {
    // Full-resolution RAW processing uses substantial memory. A fresh decoder
    // for each file makes that allocation reclaimable before the next file.
    raw.dispose();
  }
}

function readableError(error) {
  const message = error?.message || String(error);
  if (/memory|allocation|out of bounds/i.test(message)) {
    return 'Bu fotoğraf için yeterli bellek yok. Diğer sekmeleri kapatıp tekrar deneyin.';
  }
  if (/open_buffer|unpack\(\)|dcraw_process|no image/i.test(message)) {
    return 'Bu RAW dosyası okunamadı. Dosya bozuk olabilir veya kamera modeli henüz desteklenmiyor.';
  }
  if (/fetch|import|network/i.test(message)) {
    return 'Dönüştürme motoru yüklenemedi. İnternet bağlantısını kontrol edip sayfayı yenileyin.';
  }
  return message;
}

self.onmessage = ({ data }) => {
  queue = queue.then(async () => {
    try {
      const result = await processRaw(data);
      self.postMessage({ id: data.id, result }, result.rgba ? [result.rgba] : []);
    } catch (error) {
      self.postMessage({ id: data.id, error: readableError(error) });
    }
  });
};
