import './style.css';
import { zip } from 'fflate';
import { convertRaw, disposeEngine } from './engine.js';
import { MAX_FILE_BYTES, fileKey, formatBytes, uniqueJpegName, readEntry, saveInDirectory } from './files.js';

const $ = (id) => document.getElementById(id);
let files = [], results = [], directory = null, running = false, cancelled = false, adding = false;
const keys = new Set();
const queueEmpty = $('file-list').innerHTML;
const controlIds = ['add-files', 'add-folder', 'clear-files', 'quality', 'choose-output', 'file-input', 'folder-input'];

function status(message) { $('status').textContent = message; }
function setBusy(value) {
  running = value;
  for (const id of controlIds) $(id).disabled = value;
  $('convert').disabled = value || !files.length || !crossOriginIsolated;
  $('cancel').disabled = !value;
  $('cancel').hidden = !value;
  if (value) $('progress').hidden = false;
  $('clear-files').disabled = value || !files.length;
  $('drop-zone').setAttribute('aria-disabled', String(value));
  $('download-all').disabled = value || !results.length;
}

function renderQueue() {
  $('file-count').textContent = `${files.length} fotoğraf`;
  $('file-list').replaceChildren();
  if (!files.length) $('file-list').innerHTML = queueEmpty;
  for (const file of files) {
    const row = document.createElement('li');
    row.className = 'file-row';
    const badge = document.createElement('span'); badge.className = 'file-type'; badge.textContent = 'RAW';
    const detail = document.createElement('div'); detail.className = 'file-info';
    const name = document.createElement('strong'); name.className = 'file-name'; name.textContent = file.name;
    const meta = document.createElement('span'); meta.className = 'file-meta'; meta.textContent = `${formatBytes(file.size)} · CR3`;
    detail.append(name, meta);
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'file-remove';
    remove.textContent = '×'; remove.setAttribute('aria-label', `${file.name} dosyasını kaldır`);
    remove.disabled = running;
    remove.addEventListener('click', () => {
      if (running) return;
      keys.delete(fileKey(file)); files = files.filter((item) => item !== file); renderQueue();
    });
    row.append(badge, detail, remove); $('file-list').append(row);
  }
  $('convert').disabled = running || !files.length || !crossOriginIsolated;
  $('clear-files').disabled = running || !files.length;
}

function addFiles(incoming) {
  if (running) return;
  let count = 0, skipped = 0;
  for (const file of incoming) {
    if (!/\.cr3$/i.test(file.name) || !file.size || file.size > MAX_FILE_BYTES) { skipped++; continue; }
    const key = fileKey(file);
    if (keys.has(key)) continue;
    keys.add(key); files.push(file); count++;
  }
  renderQueue();
  status(`${count} fotoğraf eklendi. ${files.length} fotoğraf hazır.${skipped ? ` ${skipped} dosya atlandı; dolu, 200 MB altı CR3 dosyaları seçin.` : ''}`);
}

function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url; link.download = name;
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

function renderResult(result) {
  const row = document.createElement('li'); row.className = 'result-row';
  const img = document.createElement('img'); img.src = result.url; img.alt = ''; img.loading = 'lazy';
  const detail = document.createElement('div'); detail.className = 'file-info';
  const name = document.createElement('strong'); name.className = 'result-name'; name.textContent = result.name;
  const meta = document.createElement('span'); meta.className = 'file-meta';
  meta.textContent = `${result.width} × ${result.height} · ${formatBytes(result.blob.size)}${result.saved ? ' · Klasöre kaydedildi' : ''}`;
  detail.append(name, meta);
  if (result.saveError) {
    const warning = document.createElement('span'); warning.className = 'save-warning';
    warning.textContent = 'Klasöre kaydedilemedi. İndir düğmesini kullanın.'; detail.append(warning);
  }
  const link = document.createElement('a'); link.className = 'button button--secondary'; link.href = result.url;
  link.download = result.name; link.textContent = 'İndir';
  row.append(img, detail, link); $('result-list').append(row);
  $('results').hidden = false;
}

$('add-files').addEventListener('click', () => $('file-input').click());
$('add-folder').addEventListener('click', () => $('folder-input').click());
for (const id of ['file-input', 'folder-input']) $(id).addEventListener('change', (event) => {
  addFiles(event.target.files); event.target.value = '';
});
$('clear-files').addEventListener('click', () => {
  if (running) return;
  files = []; keys.clear(); renderQueue(); status('Liste temizlendi.'); $('progress').value = 0;
});
$('quality').addEventListener('input', () => { $('quality-value').textContent = $('quality').value; });

const dropZone = $('drop-zone');
dropZone.addEventListener('click', (event) => {
  if (!running && !adding && !event.target.closest('button')) $('file-input').click();
});
dropZone.addEventListener('keydown', (event) => {
  if (event.target === dropZone && ['Enter', ' '].includes(event.key)) {
    event.preventDefault(); if (!running) $('file-input').click();
  }
});
for (const type of ['dragover', 'drop']) window.addEventListener(type, (event) => event.preventDefault());
dropZone.addEventListener('dragover', (event) => {
  event.dataTransfer.dropEffect = running ? 'none' : 'copy';
  if (!running) dropZone.classList.add('dragging');
});
dropZone.addEventListener('dragleave', (event) => {
  if (!dropZone.contains(event.relatedTarget)) dropZone.classList.remove('dragging');
});
dropZone.addEventListener('drop', async (event) => {
  dropZone.classList.remove('dragging');
  if (running || adding) return;
  // Capture entries synchronously: the drag data store closes after this event.
  const items = [...event.dataTransfer.items];
  const entries = items.map((item) => item.webkitGetAsEntry?.()).filter(Boolean);
  const fallback = [...event.dataTransfer.files];
  adding = true; $('convert').disabled = true; status('Klasörlerdeki fotoğraflar okunuyor…');
  try {
    const found = [];
    if (entries.length) for (const entry of entries) for await (const file of readEntry(entry)) found.push(file);
    else found.push(...fallback);
    addFiles(found);
  } catch { status('Bazı dosyalar okunamadı. Dosya seç düğmesiyle yeniden deneyin.'); }
  finally { adding = false; setBusy(false); }
});

$('choose-output').addEventListener('click', async () => {
  if (!('showDirectoryPicker' in window)) {
    status('Bu tarayıcı doğrudan klasöre kaydetmeyi desteklemiyor. Dönüşüm sonrası JPEG’leri veya ZIP’i indirebilirsiniz.'); return;
  }
  try {
    const parent = await window.showDirectoryPicker({ id: 'fgo-foto', startIn: 'documents', mode: 'readwrite' });
    directory = parent.name.toLocaleLowerCase('tr') === 'fgo foto' ? parent : await parent.getDirectoryHandle('fgo foto', { create: true });
    $('output-label').textContent = `${parent.name}${parent === directory ? '' : ' / fgo foto'}`;
    status('JPEG’ler seçtiğiniz fgo foto klasörüne kaydedilecek.');
  } catch (error) {
    if (error.name !== 'AbortError') status('Klasöre erişilemedi. Farklı bir klasör seçebilir veya sonuçları indirebilirsiniz.');
  }
});

$('cancel').addEventListener('click', () => {
  cancelled = true; disposeEngine(); $('cancel').disabled = true; status('Durduruluyor… Tamamlanan JPEG’ler aşağıda kalır.');
});
$('convert').addEventListener('click', async () => {
  if (running || adding || !files.length) return;
  cancelled = false; setBusy(true); renderQueue();
  results.forEach((result) => URL.revokeObjectURL(result.url)); results = [];
  $('result-list').replaceChildren(); $('results').hidden = true;
  const usedNames = new Set(); let failed = 0, saveFailed = 0, processed = 0;
  $('progress').max = files.length; $('progress').value = 0;
  const quality = Number($('quality').value);
  try {
    for (const file of files) {
      if (cancelled) break;
      status(`${processed + 1} / ${files.length} · ${file.name} dönüştürülüyor…`);
      try {
        const result = await convertRaw(file, quality);
        if (cancelled) break;
        result.name = uniqueJpegName(file.name, usedNames);
        if (directory) {
          try { result.name = await saveInDirectory(directory, result.name, result.blob); result.saved = true; }
          catch { result.saveError = true; saveFailed++; }
        }
        result.url = URL.createObjectURL(result.blob); results.push(result); renderResult(result);
      } catch (error) {
        if (cancelled || error.name === 'AbortError') break;
        failed++;
        const row = document.createElement('li'); row.className = 'result-error';
        row.textContent = `${file.name}: ${error.message}`; $('result-list').append(row); $('results').hidden = false;
      }
      $('progress').value = ++processed;
    }
  } finally {
    disposeEngine(); setBusy(false); renderQueue();
    status(`${cancelled ? 'Durduruldu' : 'Tamamlandı'} · ${results.length} JPEG hazır${failed ? `, ${failed} dosya dönüştürülemedi` : ''}.${saveFailed ? ` ${saveFailed} JPEG için İndir düğmesini kullanın.` : ''}`);
    if (results.length) $('results').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
});

$('download-all').addEventListener('click', async () => {
  if (!results.length || running) return;
  const button = $('download-all'); button.disabled = true;
  status('ZIP hazırlanıyor…');
  try {
    const archive = Object.create(null), used = new Set();
    for (const result of results) {
      const name = uniqueJpegName(result.name.replace(/\.jpg$/i, '.cr3'), used);
      archive[name] = new Uint8Array(await result.blob.arrayBuffer());
    }
    const data = await new Promise((resolve, reject) => zip(archive, { level: 0 }, (error, bytes) => error ? reject(error) : resolve(bytes)));
    download(new Blob([data], { type: 'application/zip' }), 'fgo-foto.zip');
    status('ZIP hazır. İndirme tarayıcınızda başlatıldı.');
  } catch { status('ZIP hazırlanamadı. JPEG’leri tek tek indirebilirsiniz.'); }
  finally { button.disabled = running || !results.length; }
});

if (!window.crossOriginIsolated) {
  $('compatibility').hidden = false;
  $('compatibility').textContent = 'Dönüştürme motoru hazırlanıyor. Sayfa ilk açılışta bir kez yenilenir. Bu mesaj kalırsa güncel Chrome veya Edge ile açın ve sayfayı yenileyin.';
}
window.addEventListener('pagehide', () => { disposeEngine(); results.forEach((result) => URL.revokeObjectURL(result.url)); });
setBusy(false);
