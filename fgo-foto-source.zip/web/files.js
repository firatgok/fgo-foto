export const MAX_FILE_BYTES = 200 * 1024 * 1024;

export function fileKey(file) {
  return `${file.webkitRelativePath || file.name}\u0000${file.size}\u0000${file.lastModified}`;
}

export function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export function uniqueJpegName(filename, used) {
  const leaf = filename.split(/[\\/]/).at(-1);
  const stem = (leaf.replace(/\.cr3$/i, '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/g, '') || 'foto');
  let name = `${stem}.jpg`, index = 0;
  while (used.has(name.toLocaleLowerCase('en-US'))) name = `${stem}_${++index}.jpg`;
  used.add(name.toLocaleLowerCase('en-US'));
  return name;
}

export async function* readEntry(entry) {
  if (entry.isFile) {
    yield await new Promise((resolve, reject) => entry.file(resolve, reject));
  } else if (entry.isDirectory) {
    const reader = entry.createReader();
    while (true) {
      const batch = await new Promise((resolve, reject) => reader.readEntries(resolve, reject));
      if (!batch.length) break;
      for (const child of batch) yield* readEntry(child);
    }
  }
}

export async function saveInDirectory(directory, filename, blob) {
  const stem = filename.replace(/\.jpg$/i, '');
  let candidate = filename, counter = 0;
  while (true) {
    try {
      await directory.getFileHandle(candidate);
      candidate = `${stem}_${++counter}.jpg`;
    } catch (error) {
      if (error.name !== 'NotFoundError') throw error;
      break;
    }
  }
  const handle = await directory.getFileHandle(candidate, { create: true });
  const writable = await handle.createWritable();
  try {
    await writable.write(blob);
    await writable.close();
  } catch (error) {
    await writable.abort().catch(() => {});
    throw error;
  }
  return candidate;
}
