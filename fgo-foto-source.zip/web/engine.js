// LibRaw and JPEG encoding run in workers. Only local File bytes are transferred.
let activeWorker = null;
let nextId = 0;
let generation = 0;
let queue = Promise.resolve();
const pending = new Map();
const JOB_TIMEOUT_MS = 5 * 60 * 1000;

function cancelledError() {
  return new DOMException('Dönüştürme durduruldu.', 'AbortError');
}

function failPending(error) {
  for (const { reject, timeout } of pending.values()) {
    clearTimeout(timeout);
    reject(error);
  }
  pending.clear();
}

function getWorker() {
  if (!globalThis.WebAssembly || !globalThis.Worker) {
    throw new Error('Bu tarayıcı RAW dönüştürmeyi desteklemiyor. Güncel Chrome veya Edge kullanın.');
  }
  if (!globalThis.crossOriginIsolated || typeof SharedArrayBuffer === 'undefined') {
    throw new Error('Dönüştürme motoru henüz hazır değil. Sayfayı yenileyin; sorun sürerse güncel Chrome veya Edge ile açın.');
  }
  if (!activeWorker) {
    const worker = new Worker(new URL('./worker.js', import.meta.url), { type: 'module' });
    activeWorker = worker;
    worker.onmessage = ({ data }) => {
      const entry = pending.get(data.id);
      if (!entry) return;
      clearTimeout(entry.timeout);
      pending.delete(data.id);
      if (data.error) entry.reject(new Error(data.error));
      else entry.resolve(data.result);
    };
    worker.onerror = () => {
      worker.terminate();
      if (activeWorker === worker) activeWorker = null;
      failPending(new Error('Dönüştürme motoru çalıştırılamadı. Sayfayı yenileyin veya daha küçük bir dosya deneyin.'));
    };
    worker.onmessageerror = () => {
      worker.terminate();
      if (activeWorker === worker) activeWorker = null;
      failPending(new Error('Dönüştürülen görüntü okunamadı. Dosyayı yeniden deneyin.'));
    };
  }
  return activeWorker;
}

async function encodeOnMainThread(result, quality) {
  // Fallback for browsers without worker-side OffscreenCanvas JPEG encoding.
  if (result.blob) return result;
  const canvas = document.createElement('canvas');
  canvas.width = result.width;
  canvas.height = result.height;
  try {
    const context = canvas.getContext('2d', { alpha: false, colorSpace: 'srgb' });
    if (!context) throw new Error('JPEG görüntüsü oluşturulamadı.');
    context.putImageData(new ImageData(new Uint8ClampedArray(result.rgba), result.width, result.height), 0, 0);
    const blob = await new Promise((resolve, reject) => {
      canvas.toBlob((value) => value ? resolve(value) : reject(new Error('JPEG dosyası oluşturulamadı.')), 'image/jpeg', quality / 100);
    });
    return { blob, width: result.width, height: result.height };
  } finally {
    canvas.width = 0;
    canvas.height = 0;
  }
}

/** Convert a local RAW File to a full-resolution sRGB JPEG. Quality is 1–100. */
export function convertRaw(file, quality = 95) {
  const jobGeneration = generation;
  const job = queue.then(async () => {
    if (jobGeneration !== generation) throw cancelledError();
    if (!file || typeof file.arrayBuffer !== 'function' || !file.size) {
      throw new Error('Boş veya okunamayan dosya.');
    }
    const jpegQuality = Number(quality);
    if (!Number.isFinite(jpegQuality) || jpegQuality < 1 || jpegQuality > 100) {
      throw new Error('JPEG kalitesi 1 ile 100 arasında olmalı.');
    }
    const worker = getWorker();
    const buffer = await file.arrayBuffer();
    if (jobGeneration !== generation) throw cancelledError();
    const id = ++nextId;
    const result = await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        worker.terminate();
        if (activeWorker === worker) activeWorker = null;
        failPending(new Error('Bu dosyanın dönüştürülmesi çok uzun sürdü. Daha güçlü bir bilgisayarda tekrar deneyin.'));
      }, JOB_TIMEOUT_MS);
      pending.set(id, { resolve, reject, timeout });
      const moduleUrl = new URL(`${import.meta.env.BASE_URL}vendor/libraw/index.js`, location.href).href;
      try {
        worker.postMessage({ id, buffer, quality: jpegQuality, moduleUrl }, [buffer]);
      } catch (error) {
        clearTimeout(timeout);
        pending.delete(id);
        reject(error);
      }
    });
    if (jobGeneration !== generation) throw cancelledError();
    const encoded = await encodeOnMainThread(result, jpegQuality);
    if (jobGeneration !== generation) throw cancelledError();
    return encoded;
  });
  // Keep subsequent files usable after an individual decode fails.
  queue = job.catch(() => {});
  return job;
}

/** Stop the current conversion and release all worker/WASM memory. */
export function disposeEngine() {
  generation += 1;
  activeWorker?.terminate();
  activeWorker = null;
  failPending(cancelledError());
  queue = Promise.resolve();
}
